package com.controller;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MainController implements Initializable {

    @FXML
    private Button allitems_btn;

    @FXML
    private Button favorite_btn;

    @FXML
    private Button trash_btn;

    @FXML
    private Button covid_btn;

    @FXML
    private Button politic_btn;

    @FXML
    private Button business_btn;

    @FXML
    private Button technology_btn;

    @FXML
    private Button sport_btn;

    @FXML
    private Button health_btn;

    @FXML
    private Button onehour_btn;

    @FXML
    private Button fourhour_btn;

    @FXML
    private Button twelvehour_btn;

    @FXML
    private Button foureighthour_btn;
    @FXML
    private VBox mother;

    @FXML
    private Label category_lb;

    @FXML
    private Label time_lb;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {



        try {
            FXMLLoader food = new FXMLLoader();
            food.setLocation(getClass().getResource("/mainitem.fxml"));
            food.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
