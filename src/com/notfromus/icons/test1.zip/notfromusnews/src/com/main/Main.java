package com.main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;


public class Main extends Application {

    private double y;
    private double x;

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("../fxml/main.fxml"));
        primaryStage.setScene(new Scene(root));
        primaryStage.initStyle(StageStyle.UNDECORATED);

        root.setOnMousePressed(mouseEvent -> {
            x = mouseEvent.getSceneX();
            y = mouseEvent.getSceneY();
        });

        root.setOnMouseDragged(mouseEvent -> {
            primaryStage.setX(mouseEvent.getSceneX() - x);
            primaryStage.setY(mouseEvent.getSceneX() - y);
        });
        primaryStage.show();
    }


    public static void main(String[] args) throws InterruptedException {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter times you want to replay please: ");
        int count;
        try {
            count = scan.nextInt();
        } catch (InputMismatchException e) {
            System.out.println(e);
            System.out.print("A number only");
            return;
        }
        while (count-- > 0) {
            Task task = new Task();
            task.run();
        }
        System.out.println("End of program");

    }
}
